package com.drware.todoplus.v1.startup.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.drware.todoplus.v1.startup.data.model.Todo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class TodoViewModel : ViewModel() {

    private val _todos = MutableStateFlow<List<Todo>>(emptyList())
    val todos: StateFlow<List<Todo>> = _todos

    fun addTodo(title: String) {
        val newTodo = Todo(
            id = UUID.randomUUID().toString(),
            title = title,
            completed = false
        )

        // In-memory update
        _todos.update { current -> current + newTodo }

        // TODO: Save to Room (if applicable)
        // viewModelScope.launch(Dispatchers.IO) {
        //     repository.insertTodo(newTodo)
        // }
    }

    fun deleteTodo(todo: Todo) {
        _todos.update { current -> current.filter { it.id != todo.id } }

        // TODO: Delete from Room
        // viewModelScope.launch(Dispatchers.IO) {
        //     repository.deleteTodo(todo)
        // }
    }

    fun toggleDone(todoId: String) {
        _todos.update { current ->
            current.map { todo ->
                if (todo.id == todoId) todo.copy(completed = !todo.completed) else todo
            }
        }

        // TODO: Update in Room
        // viewModelScope.launch(Dispatchers.IO) {
        //     repository.updateTodo(updatedTodo)
        // }
    }

    fun onEditClick(todo: Todo) {
        // Placeholder for edit logic
    }
}
