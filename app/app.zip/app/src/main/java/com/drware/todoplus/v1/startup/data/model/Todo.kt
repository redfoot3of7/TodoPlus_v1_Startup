// Todo.kt — 2025-08-07 10:09
package com.drware.todoplus.v1.startup.data.model

import java.time.LocalDate

// Represents a single todo item
data class Todo(
    val id: String,
    val title: String,
    val description: String = "",
    val dueDate: LocalDate? = null,
    val inputType: String = "General",
    val completed: Boolean = false // New field to mark if task is completed
)
