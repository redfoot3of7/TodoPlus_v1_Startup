// Navigation.kt — 2025-08-07 17:40
package com.drware.todoplus.v1.startup.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.drware.todoplus.v1.startup.data.screens.HelpScreen
import com.drware.todoplus.v1.startup.data.screens.TodoMainScreen
import com.drware.todoplus.v1.startup.viewmodel.TodoViewModel

object Routes {
    const val MAIN = "main"
    const val HELP = "help"
}

@Composable
fun TodoNavHost(
    navController: NavHostController,
    viewModel: TodoViewModel,
    isLocked: Boolean,
    onAuthenticate: () -> Unit,
    onLockApp: () -> Unit
) {
    NavHost(navController = navController, startDestination = Routes.MAIN) {
        composable(Routes.MAIN) {
            TodoMainScreen(
                viewModel = viewModel,
                isLocked = isLocked,
                onAuthenticate = onAuthenticate,
                onLockApp = onLockApp,
                onHelpClick = { navController.navigate(Routes.HELP) }  // Provide this!'
            )
        }
        composable(Routes.HELP) {
            HelpScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
