// TodoMainScreen.kt — 2025-08-07 17:10
package com.drware.todoplus.v1.startup.data.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.drware.todoplus.v1.startup.data.model.Todo
import com.drware.todoplus.v1.startup.ui.TodoInputDialog
import com.drware.todoplus.v1.startup.ui.TodoList
import com.drware.todoplus.v1.startup.viewmodel.TodoViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TodoMainScreen(
    viewModel: TodoViewModel,
    isLocked: Boolean,
    onAuthenticate: () -> Unit,
    onLockApp: () -> Unit,
    onHelpClick: () -> Unit  // Added this parameter for Help navigation
) {
    if (isLocked) {
        // Show biometric auth UI or lock screen placeholder
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally
            ) {
                Text("App is locked. Please authenticate.")
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onAuthenticate) {
                    Text("Authenticate")
                }
            }
        }
    } else {
        var showDialog by remember { mutableStateOf(false) }

        val todosState = viewModel.todos.collectAsState(initial = emptyList())
        val todos = todosState.value

        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("TodoPlus") },
                    actions = {
                        TextButton(onClick = onLockApp) {
                            Text("Lock")
                        }
                        TextButton(onClick = onHelpClick) {  // Help button added
                            Text("Help")
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showDialog = true },
                    modifier = Modifier.padding(16.dp)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = "Add Todo")
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .padding(16.dp)
                    .fillMaxSize()
            ) {
                TodoList(
                    todos = todos,
                    onEditClick = { todo -> viewModel.onEditClick(todo) },
                    onDeleteClick = { todo -> viewModel.deleteTodo(todo) },
                    onToggleDone = { todo -> viewModel.toggleDone(todo.id) }
                )
            }

            if (showDialog) {
                TodoInputDialog(
                    onDismiss = { showDialog = false },
                    onSave = { title ->
                        viewModel.addTodo(title)
                        showDialog = false
                    }
                )
            }
        }
    }
}
