// Color.kt — 2025-08-04 12:15
package com.drware.todoplus.v1.startup.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val md_theme_light_primary = Color(0xFF006D3F)
val md_theme_light_onPrimary = Color(0xFFFFFFFF)
val md_theme_light_primaryContainer = Color(0xFF8DF7BB)
val md_theme_light_onPrimaryContainer = Color(0xFF00210F)
val md_theme_light_secondary = Color(0xFF4D6356)
val md_theme_light_onSecondary = Color(0xFFFFFFFF)
val md_theme_light_secondaryContainer = Color(0xFFD0E8D8)
val md_theme_light_onSecondaryContainer = Color(0xFF0A1F15)
val md_theme_light_background = Color(0xFFFBFDF8)
val md_theme_light_onBackground = Color(0xFF191C1A)
val md_theme_light_surface = Color(0xFFFBFDF8)
val md_theme_light_onSurface = Color(0xFF191C1A)
val md_theme_light_error = Color(0xFFBA1A1A)
val md_theme_light_onError = Color(0xFFFFFFFF)

// Dark Theme Colors
val md_theme_dark_primary = Color(0xFF70DBA0)
val md_theme_dark_onPrimary = Color(0xFF00391F)
val md_theme_dark_primaryContainer = Color(0xFF00522E)
val md_theme_dark_onPrimaryContainer = Color(0xFF8DF7BB)
val md_theme_dark_secondary = Color(0xFFB5CCBC)
val md_theme_dark_onSecondary = Color(0xFF203528)
val md_theme_dark_secondaryContainer = Color(0xFF364B3E)
val md_theme_dark_onSecondaryContainer = Color(0xFFD0E8D8)
val md_theme_dark_background = Color(0xFF191C1A)
val md_theme_dark_onBackground = Color(0xFFE1E3DF)
val md_theme_dark_surface = Color(0xFF191C1A)
val md_theme_dark_onSurface = Color(0xFFE1E3DF)
val md_theme_dark_error = Color(0xFFFFB4AB)
val md_theme_dark_onError = Color(0xFF690005)

// Additional Custom Colors (if needed)
val seed = Color(0xFF00BF69)
