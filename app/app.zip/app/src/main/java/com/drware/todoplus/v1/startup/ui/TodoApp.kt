// TodoApp.kt — 2025-08-07 17:20
package com.drware.todoplus.v1.startup.ui

import androidx.compose.runtime.Composable
import com.drware.todoplus.v1.startup.data.screens.TodoMainScreen
import com.drware.todoplus.v1.startup.viewmodel.TodoViewModel

@Composable
fun TodoApp(
    isLocked: Boolean,
    onAuthenticate: () -> Unit,
    onLockApp: () -> Unit,
    onHelpClick: () -> Unit   // Added parameter for Help navigation
) {
    TodoMainScreen(
        isLocked = isLocked,
        onAuthenticate = onAuthenticate,
        onLockApp = onLockApp,
        onHelpClick = onHelpClick,  // Pass it down
        viewModel = androidx.lifecycle.viewmodel.compose.viewModel<TodoViewModel>()
    )
}
